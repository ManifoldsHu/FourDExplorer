4dExplorer 版本 0.0.4

该版本仅供小范围测试，其得到的任何计算结果公开使用所造成的后果由用户承担。
This version is for test only. 